# 数独问题

+ 程序编译方式：g++ -o \*\*.exe -g \*\*.cpp -O3（sudoku.cpp为简单的回溯算法实现，sudoku_perfect.cpp为优化实现）
+ 运行方法：**.exe i  &nbsp; &nbsp; (i代表第i个测试样例，取值1,2,3)